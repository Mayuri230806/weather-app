from django.urls import path
from . import views

urlpatterns = [
         path('', views.index),
         path('', views.weather_view, name='weather-home'),
         path('city-suggestions/', views.city_suggestions, name='city-suggestions'),
         
]
